<?php
session_start();
require_once("../config/connection.php");

// Verifica se usuário está logado
if(!isset($_SESSION['user_id'])){
    header("Location: ../index.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Verifica se veio o ID do animal
if(!isset($_GET['id']) || empty($_GET['id'])){
    header("Location: home.php");
    exit;
}

$animal_id = intval($_GET['id']);

// Verifica se o animal pertence ao usuário logado
$stmt = $conn->prepare("SELECT id_usuario FROM animais WHERE id=:id LIMIT 1");
$stmt->execute([':id'=>$animal_id]);
$animal = $stmt->fetch(PDO::FETCH_ASSOC);

if(!$animal || $animal['id_usuario'] != $user_id){
    // Tentativa de deletar animal que não é do usuário
    die("Acesso negado!");
}

// Deleta o animal
$stmt = $conn->prepare("DELETE FROM animais WHERE id=:id");
$stmt->execute([':id'=>$animal_id]);

// Redireciona para a home
header("Location: home.php");
exit;
?>
