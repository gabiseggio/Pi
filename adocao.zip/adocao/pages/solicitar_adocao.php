<?php
session_start();
require_once("../config/connection.php");

if (!isset($_SESSION['user_id']) || $_SESSION['tipo'] !== 'adotante') {
    header("Location: ../index.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$mensagem = '';

if (!isset($_GET['id_animal'])) {
    die("Animal inválido!");
}

$id_animal = intval($_GET['id_animal']);

// Pega dados do animal
$stmt = $conn->prepare("SELECT * FROM animais WHERE id = :id");
$stmt->execute([':id' => $id_animal]);
$animal = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$animal) {
    die("Animal não encontrado!");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $maioridade = isset($_POST['maioridade']) ? 1 : 0;
    $endereco = trim($_POST['endereco']);
    $telefone = trim($_POST['telefone']);
    $rg = trim($_POST['rg']);
    $cpf = trim($_POST['cpf']);
    $termo = isset($_POST['termo']) ? 1 : 0;

    // Upload de comprovante
    $comprovante_path = '';
    if (isset($_FILES['comprovante']) && $_FILES['comprovante']['error'] === UPLOAD_ERR_OK) {
        $ext = pathinfo($_FILES['comprovante']['name'], PATHINFO_EXTENSION);
        $nomeArquivo = 'comprovante_'.$user_id.'_'.time().'.'.$ext;
        $caminho = '../uploads/'.$nomeArquivo;
        if (move_uploaded_file($_FILES['comprovante']['tmp_name'], $caminho)) {
            $comprovante_path = $nomeArquivo;
        }
    }

    // Inserir no banco
    $stmt_insert = $conn->prepare("
        INSERT INTO formularios_adocao
        (id_animal, id_adotante, maioridade, endereco, telefones, rg, cpf, comprovante, termo_assinado)
        VALUES
        (:id_animal, :id_adotante, :maioridade, :endereco, :telefone, :rg, :cpf, :comprovante, :termo)
    ");

    $stmt_insert->execute([
        ':id_animal' => $id_animal,
        ':id_adotante' => $user_id,
        ':maioridade' => $maioridade,
        ':endereco' => $endereco,
        ':telefone' => $telefone,
        ':rg' => $rg,
        ':cpf' => $cpf,
        ':comprovante' => $comprovante_path,
        ':termo' => $termo
    ]);

    $mensagem = "Solicitação enviada com sucesso!";
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Solicitar Adoção - <?php echo htmlspecialchars($animal['nome']); ?></title>
<style>
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    background: #f0f4f8;
    padding: 20px;
    display: flex;
    justify-content: center;
    align-items: flex-start;
    min-height: 100vh;
}

.container {
    background: #fff;
    padding: 35px 30px;
    border-radius: 20px;
    max-width: 500px;
    width: 100%;
    box-shadow: 0 10px 25px rgba(0,0,0,0.15);
    transition: transform 0.3s;
}

.container:hover {
    transform: translateY(-3px);
}

h2 {
    text-align: center;
    color: #ff4fa3;
    margin-bottom: 25px;
    font-size: 1.8em;
}

label {
    display: block;
    margin-top: 12px;
    font-weight: bold;
    color: #333;
    position: relative;
    padding-left: 28px;
}

input[type="text"],
input[type="file"],
textarea {
    width: 100%;
    padding: 12px;
    margin-top: 6px;
    border-radius: 12px;
    border: 1px solid #ccc;
    outline: none;
    transition: 0.3s;
}

input[type="text"]:focus,
textarea:focus,
input[type="file"]:focus {
    border-color: #007bff;
    box-shadow: 0 0 8px rgba(0,123,255,0.25);
}

button {
    margin-top: 20px;
    width: 100%;
    padding: 14px;
    background: linear-gradient(90deg,#007bff,#ff4fa3);
    color: #fff;
    border: none;
    border-radius: 14px;
    font-size: 1em;
    cursor: pointer;
    font-weight: bold;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    transition: 0.3s;
}

button:hover {
    opacity: 0.9;
    transform: translateY(-2px);
}

.mensagem {
    color: green;
    font-weight: bold;
    margin-bottom: 15px;
    text-align: center;
    font-size: 1.1em;
}

.checkbox-label {
    display: flex;
    align-items: center;
    gap: 10px;
    font-weight: normal;
    color: #555;
}

/* Ícones dentro do form */
label::before {
    content: '';
    position: absolute;
    left: 0;
    top: 50%;
    transform: translateY(-50%);
    width: 20px;
    height: 20px;
    background-size: contain;
    background-repeat: no-repeat;
}

label[for="endereco"]::before { background-image: url('https://img.icons8.com/ios/24/007bff/address--v1.png'); }
label[for="telefone"]::before { background-image: url('https://img.icons8.com/ios/24/007bff/phone.png'); }
label[for="rg"]::before { background-image: url('https://img.icons8.com/ios/24/007bff/id-card.png'); }
label[for="cpf"]::before { background-image: url('https://img.icons8.com/ios/24/007bff/identification-doc.png'); }
label[for="comprovante"]::before { background-image: url('https://img.icons8.com/ios/24/007bff/upload.png'); }

/* Ícone de check em checkbox */
input[type="checkbox"] {
    accent-color: #ff4fa3; /* cor do check */
    transform: scale(1.2);
}
</style>
</head>
<body>
<div class="container">
<h2>Solicitar Adoção: <?php echo htmlspecialchars($animal['nome']); ?></h2>
<?php if($mensagem): ?>
    <p class="mensagem"><?php echo $mensagem; ?></p>
<?php endif; ?>
<form action="" method="post" enctype="multipart/form-data">
    <label class="checkbox-label"><input type="checkbox" name="maioridade" required> Sou maior de idade ✅</label>

    <label for="endereco">Endereço fixo:</label>
    <textarea name="endereco" id="endereco" required rows="3"></textarea>

    <label for="telefone">Telefone de contato:</label>
    <input type="text" name="telefone" id="telefone" required>

    <label for="rg">RG:</label>
    <input type="text" name="rg" id="rg" required>

    <label for="cpf">CPF:</label>
    <input type="text" name="cpf" id="cpf" required>

    <label for="comprovante">Comprovante de residência:</label>
    <input type="file" name="comprovante" id="comprovante" accept="image/*,application/pdf" required>

    <label class="checkbox-label"><input type="checkbox" name="termo" required> Me responsabilizo pelo animal e permito monitoramento mínimo de 6 meses ✅</label>

    <button type="submit">
        <img src="https://img.icons8.com/ios/24/ffffff/paper-plane--v1.png" alt="Enviar">
        Enviar Solicitação
    </button>
</form>
</div>
</body>
</html>
