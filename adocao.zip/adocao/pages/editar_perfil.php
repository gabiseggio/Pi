<?php
session_start();
require_once("../config/connection.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Pega dados atuais
$stmt = $conn->prepare("SELECT foto_perfil, bio FROM usuarios WHERE id = :id");
$stmt->execute([':id' => $user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
$foto_perfil = $user['foto_perfil'] ?? 'default.png';
$bio = $user['bio'] ?? '';

$mensagem = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nova_bio = $_POST['bio'] ?? '';

    // Atualiza bio
    $stmt = $conn->prepare("UPDATE usuarios SET bio = :bio WHERE id = :id");
    $stmt->execute([':bio' => $nova_bio, ':id' => $user_id]);
    $_SESSION['bio'] = $nova_bio;

    // Upload de foto
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $ext = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
        $nomeArquivo = 'perfil_'.$user_id.'_'.time().'.'.$ext;
        $caminho = '../uploads/'.$nomeArquivo;

        if (move_uploaded_file($_FILES['foto']['tmp_name'], $caminho)) {
            // Atualiza banco
            $stmt = $conn->prepare("UPDATE usuarios SET foto_perfil = :foto WHERE id = :id");
            $stmt->execute([':foto' => $nomeArquivo, ':id' => $user_id]);
            $_SESSION['foto_perfil'] = $nomeArquivo;
        }
    }

    $mensagem = "Perfil atualizado com sucesso!";
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Editar Perfil</title>
<link rel="icon" type="image/png" href="img/logo.png">
<style>
body {
    font-family: Arial, sans-serif;
    background: #fff;
    margin: 0;
    display: flex;
}

.sidebar { 
    width:200px; 
    background:#fff; /* fundo branco */
    padding:20px; 
    height:100vh; 
    box-shadow:2px 0 5px rgba(0,0,0,0.1); 
}
.sidebar h3 { 
    margin-bottom:20px; 
    display:flex; 
    align-items:center; 
    font-size:1em;
}
.sidebar img.profile { 
    width:40px; 
    height:40px; 
    border-radius:50%; 
    margin-right:10px; 
    object-fit:cover; 
}
.sidebar a { 
    display:block; 
    margin:12px 0; 
    text-decoration:none; 
    color:#333; 
    font-weight:bold; 
}
.sidebar a img.icon { 
    vertical-align:middle; 
    margin-right:8px; 
    width:24px; 
}
.content {
    flex: 1;
    padding: 20px;
}
h2 {
    text-align: center;
}
form {
    max-width: 400px;
    margin: 0 auto;
    display: flex;
    flex-direction: column;
    gap: 15px;
}
input[type="file"] {
    padding: 5px;
}
textarea {
    padding: 8px;
    border-radius: 6px;
    border: 1px solid #ccc;
    resize: none;
}
button {
    padding: 10px;
    border: none;
    border-radius: 8px;
    background: #007bff;
    color: #fff;
    cursor: pointer;
}
.mensagem {
    text-align: center;
    color: green;
    font-weight: bold;
}
</style>
</head>
<body>
<div class="sidebar">
<img src="../img/logo.png" alt="logo" style="width:50px; display:block; margin:0 auto 15px auto;">
    <h3>
      <img src="../uploads/<?php echo htmlspecialchars($foto_perfil); ?>" alt="Foto perfil" class="profile">
      @<?php echo htmlspecialchars($_SESSION['username']); ?>
    </h3>
    <a href="home.php">
      <img src="https://img.icons8.com/ios/24/000000/home.png" class="icon" alt="Início">
      Início
    </a>
    <a href="<?php echo $_SESSION['tipo']==='doador' ? 'notificacoes.php' : 'notificacoes_adotante.php'; ?>">
      <img src="https://img.icons8.com/ios/24/000000/appointment-reminders.png" class="icon" alt="Notificações">
      Notificações
    </a>
    <a href="mensagens.php">
      <img src="https://img.icons8.com/ios/24/000000/chat.png" class="icon" alt="Mensagens">
      Mensagens
    </a>
    <a href="perfil.php">
      <img src="https://img.icons8.com/ios/24/000000/user.png" class="icon" alt="Perfil">
      Perfil
    </a>
    <?php if ($_SESSION['tipo'] === "doador"): ?>
      <a href="postar_animal.php">
        <img src="https://img.icons8.com/ios/24/000000/plus-math.png" class="icon" alt="Postar Animal">
        Postar Animal
      </a>
    <?php endif; ?>
    <a href="../auth/logout.php">
      <img src="https://img.icons8.com/ios/24/000000/exit.png" class="icon" alt="Sair">
      Sair
    </a>
</div>
<div class="content">
<h2>Editar Perfil</h2>
<?php if($mensagem): ?>
    <p class="mensagem"><?php echo $mensagem; ?></p>
<?php endif; ?>
<form action="" method="post" enctype="multipart/form-data">
    <label>Foto de Perfil:</label>
    <input type="file" name="foto" accept="image/*">

    <label>Bio:</label>
    <textarea name="bio" rows="4"><?php echo htmlspecialchars($bio); ?></textarea>

    <button type="submit">Salvar Alterações</button>
</form>
</div>
</body>
</html>