<?php
session_start();
require_once("../config/connection.php");

// Se não estiver logado, redireciona para o login
if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit;
}

// Pega dados do usuário logado
$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$tipo = $_SESSION['tipo'];
$foto_perfil = $_SESSION['foto_perfil'] ?? 'default.png';

// Busca todos os chats em que o usuário está envolvido
$sql = "SELECT
            c.id AS chat_id,
            a.nome AS animal_nome,
            -- Seleciona os dados do OUTRO usuário no chat
            CASE
                WHEN c.id_doador = :user_id THEN u_adotante.username
                ELSE u_doador.username
            END AS other_user_name,
            CASE
                WHEN c.id_doador = :user_id THEN u_adotante.foto_perfil
                ELSE u_doador.foto_perfil
            END AS other_user_foto
        FROM chats c
        JOIN animais a ON c.id_animal = a.id
        JOIN usuarios u_doador ON c.id_doador = u_doador.id
        JOIN usuarios u_adotante ON c.id_adotante = u_adotante.id
        WHERE c.id_doador = :user_id OR c.id_adotante = :user_id
        ORDER BY c.criado_em DESC";

$stmt = $conn->prepare($sql);
$stmt->execute([':user_id' => $user_id]);
$chats = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Contagem de notificações (código copiado de home.php para consistência)
$notif_count = 0;
if($tipo === 'doador'){
    $stmt_notif = $conn->prepare("SELECT COUNT(*) FROM formularios_adocao f JOIN animais a ON f.id_animal = a.id WHERE a.id_usuario=:id AND f.status='aguardando'");
    $stmt_notif->execute([':id'=>$user_id]);
    $notif_count = $stmt_notif->fetchColumn();
} else if($tipo === 'adotante'){
    $stmt_notif = $conn->prepare("SELECT COUNT(*) FROM formularios_adocao WHERE id_adotante=:id AND status!='aguardando'");
    $stmt_notif->execute([':id'=>$user_id]);
    $notif_count = $stmt_notif->fetchColumn();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <title>Mensagens</title>
  <link rel="icon" type="image/png" href="../img/logo.png">
  <style>
    body { margin:0; font-family:Arial,sans-serif; background:#fff; display:flex; }
    .sidebar { 
        width:200px; 
        background:#fff; /* ← alterado de #f0f0f0 para branco */
        padding:20px; 
        height:100vh; 
        box-shadow:2px 0 5px rgba(0,0,0,0.1); 
    }
    .sidebar h3 { margin-bottom:20px; display:flex; align-items:center; }
    .sidebar img.profile { width:40px; height:40px; border-radius:50%; margin-right:10px; object-fit:cover; }
    .sidebar a { display:block; margin:12px 0; text-decoration:none; color:#333; font-weight:bold; }
    .sidebar a img.icon { vertical-align:middle; margin-right:5px; }
    .content { flex:1; padding:20px; }
    .chat-list-item {
        display: block;
        text-decoration: none;
        color: inherit;
        border:1px solid #ddd;
        border-radius:12px;
        padding:15px;
        margin-bottom:15px;
        box-shadow:0 0 5px rgba(0,0,0,0.1);
        display:flex;
        align-items:center;
        transition: background-color 0.2s, transform 0.2s;
    }
    .chat-list-item:hover {
        background-color: #f9f9f9;
        transform: translateY(-2px);
    }
    .chat-list-item img { width:50px; height:50px; border-radius:50%; object-fit:cover; margin-right:15px; }
    .notif-count { background:#dc3545; color:#fff; border-radius:50%; padding:2px 6px; font-size:0.8em; margin-left:5px; }
</style>
</head>
<body>
  <div class="sidebar">
  <img src="../img/logo.png" alt="logo" style="width:50px; display:block; margin:0 auto 15px auto;">
    <h3>
      <img src="../uploads/<?php echo htmlspecialchars($foto_perfil); ?>" alt="Foto perfil" class="profile">
      @<?php echo htmlspecialchars($username); ?>
    </h3>
    <a href="home.php">
      <img src="https://img.icons8.com/ios/24/000000/home.png" class="icon" alt="Início">
      Início
    </a>
    <a href="<?php echo $tipo==='doador' ? 'notificacoes.php' : 'notificacoes_adotante.php'; ?>">
      <img src="https://img.icons8.com/ios/24/000000/appointment-reminders.png" class="icon" alt="Notificações">
      Notificações
      <?php if($notif_count > 0): ?>
        <span class="notif-count"><?php echo $notif_count; ?></span>
      <?php endif; ?>
    </a>
    <a href="mensagens.php">
      <img src="https://img.icons8.com/ios/24/000000/chat.png" class="icon" alt="Mensagens">
      Mensagens
    </a>
    <a href="perfil.php">
      <img src="https://img.icons8.com/ios/24/000000/user.png" class="icon" alt="Perfil">
      Perfil
    </a>
    <?php if ($tipo === "doador"): ?>
      <a href="postar_animal.php">
        <img src="https://img.icons8.com/ios/24/000000/plus-math.png" class="icon" alt="Postar Animal">
        Postar Animal
      </a>
    <?php endif; ?>
    <a href="../auth/logout.php">
      <img src="https://img.icons8.com/ios/24/000000/exit.png" class="icon" alt="Sair">
      Sair
    </a>
  </div>

  <div class="content">
    <h2>Suas Conversas</h2>
    <?php if (empty($chats)): ?>
      <p>Nenhuma conversa iniciada ainda. Quando uma adoção for aprovada, a conversa aparecerá aqui.</p>
    <?php else: ?>
      <?php foreach ($chats as $chat): ?>
        <a href="chat.php?chat_id=<?php echo $chat['chat_id']; ?>" class="chat-list-item">
          <img src="../uploads/<?php echo htmlspecialchars($chat['other_user_foto'] ?? 'default.png'); ?>" alt="Foto de perfil">
          <div>
            <strong><?php echo htmlspecialchars($chat['other_user_name']); ?></strong><br>
            <small>Conversa sobre: <?php echo htmlspecialchars($chat['animal_nome']); ?></small>
          </div>
        </a>
      <?php endforeach; ?>
    <?php endif; ?>
  </div>
</body>
</html>