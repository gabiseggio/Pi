<?php
session_start();
require_once("../config/connection.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$chat_id = $_GET['chat_id'] ?? null;

if (!$chat_id) {
    die("Chat inválido.");
}

// Verificar se o usuário faz parte do chat
$sql = "SELECT * FROM chats WHERE id = :id AND (id_doador = :uid OR id_adotante = :uid)";
$stmt = $conn->prepare($sql);
$stmt->execute([":id" => $chat_id, ":uid" => $user_id]);
$chat = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$chat) {
    die("Você não tem acesso a este chat.");
}

// Buscar mensagens
$sql = "SELECT m.*, u.username, u.foto_perfil
        FROM mensagens m
        JOIN usuarios u ON u.id = m.id_remetente
        WHERE id_chat = :chat_id ORDER BY data_envio ASC";
$stmt = $conn->prepare($sql);
$stmt->execute([":chat_id" => $chat_id]);
$mensagens = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Enviar nova mensagem
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['mensagem'])) {
    $msg = trim($_POST['mensagem']);
    if ($msg != "") {
        $sql = "INSERT INTO mensagens (id_chat, id_remetente, mensagem) VALUES (:chat, :rem, :msg)";
        $stmt = $conn->prepare($sql);
        $stmt->execute([
            ":chat" => $chat_id,
            ":rem" => $user_id,
            ":msg" => $msg
        ]);
        header("Location: chat.php?chat_id=" . $chat_id);
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Chat</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(135deg, #ffb6f0, #9dd9ff);
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .chat-container {
            background: #fff;
            width: 450px;
            max-width: 95%;
            border-radius: 16px;
            box-shadow: 0 6px 20px rgba(0,0,0,0.15);
            display: flex;
            flex-direction: column;
            overflow: hidden;
        }
        .chat-header {
            background: linear-gradient(90deg, #ff77d0, #4ba8ff);
            color: #fff;
            padding: 15px;
            text-align: center;
            font-weight: bold;
        }
        .chat-box {
            padding: 15px;
            height: 400px;
            overflow-y: auto;
            background: #f9f9f9;
        }
        .mensagem {
            margin: 8px 0;
            padding: 10px 14px;
            border-radius: 12px;
            max-width: 70%;
            clear: both;
            display: inline-block;
            word-wrap: break-word;
        }
        .mensagem.eu {
            background: #cce5ff;
            float: right;
            text-align: right;
        }
        .mensagem.outro {
            background: #ffd6f0;
            float: left;
            text-align: left;
        }
        .mensagem small {
            display: block;
            font-size: 11px;
            margin-top: 5px;
            color: #555;
        }
        .chat-form {
            display: flex;
            border-top: 1px solid #ddd;
        }
        .chat-form input {
            flex: 1;
            padding: 12px;
            border: none;
            outline: none;
            font-size: 14px;
        }
        .chat-form button {
            background: linear-gradient(90deg, #ff77d0, #4ba8ff);
            border: none;
            padding: 12px 20px;
            color: #fff;
            font-weight: bold;
            cursor: pointer;
            transition: 0.3s;
        }
        .chat-form button:hover {
            opacity: 0.9;
        }
    </style>
</head>
<body>
    <div class="chat-container">
        <div class="chat-header">
            Chat com <?= ($user_id == $chat['id_doador'] ? "Adotante" : "Doador") ?>
        </div>

        <div class="chat-box">
            <?php foreach ($mensagens as $m): ?>
                <div class="mensagem <?= $m['id_remetente'] == $user_id ? 'eu' : 'outro' ?>">
                    <strong><?= htmlspecialchars($m['username']) ?>:</strong><br>
                    <?= htmlspecialchars($m['mensagem']) ?>
                    <small><?= $m['data_envio'] ?></small>
                </div>
            <?php endforeach; ?>
        </div>

        <form class="chat-form" method="post">
            <input type="text" name="mensagem" placeholder="Digite sua mensagem..." required>
            <button type="submit">Enviar</button>
        </form>
    </div>
</body>
</html>
