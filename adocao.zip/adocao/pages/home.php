<?php
session_start();
require_once("../config/connection.php");

// Se não estiver logado, manda pro login
if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit;
}

// Pega usuário logado
$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$tipo = $_SESSION['tipo'];
$foto_perfil = $_SESSION['foto_perfil'] ?? 'default.png';

// --- LÓGICA DO FILTRO ---
$filtro_tipo = $_GET['filtro'] ?? 'todos'; // Pega o filtro da URL, padrão é 'todos'
$params = [];

// Busca todos os animais disponíveis
$sql = "SELECT a.*, u.username, u.foto_perfil 
        FROM animais a 
        JOIN usuarios u ON a.id_usuario = u.id
        WHERE a.status = 'disponivel'";

// Adiciona o filtro na consulta SQL se não for 'todos'
if ($filtro_tipo === 'cachorro' || $filtro_tipo === 'gato') {
    $sql .= " AND a.tipo = :tipo";
    $params[':tipo'] = $filtro_tipo;
}

$sql .= " ORDER BY a.data_postagem DESC";
$stmt = $conn->prepare($sql);
$stmt->execute($params);
$animais = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Contagem de notificações
$notif_count = 0;
if($tipo === 'doador'){
    $stmt_notif = $conn->prepare("SELECT COUNT(*) FROM formularios_adocao f JOIN animais a ON f.id_animal = a.id WHERE a.id_usuario=:id AND f.status='aguardando'");
    $stmt_notif->execute([':id'=>$user_id]);
    $notif_count = $stmt_notif->fetchColumn();
} else if($tipo === 'adotante'){
    $stmt_notif = $conn->prepare("SELECT COUNT(*) FROM formularios_adocao WHERE id_adotante=:id AND status!='aguardando'");
    $stmt_notif->execute([':id'=>$user_id]);
    $notif_count = $stmt_notif->fetchColumn();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-g">
  <title>Home</title>
  <link rel="icon" type="image/png" href="../img/logo.png">
  <style>
    body { 
      margin:0; 
      font-family:Arial,sans-serif; 
      background:#f4f4f4; 
      display:flex; 
    }
    
    .sidebar { 
      width:200px; 
      background:#fff; 
      padding:20px; 
      height:100vh; 
      position:fixed; 
      box-shadow:2px 0 5px rgba(0,0,0,0.1); 
    }
    .sidebar h3 { 
      margin-bottom:20px; 
      display:flex; 
      align-items:center; 
      font-size:1em; 
    }
    .sidebar img.profile { 
      width:40px; 
      height:40px; 
      border-radius:50%; 
      margin-right:10px; 
      object-fit:cover; 
    }
    .sidebar a { 
      display:block; 
      margin:15px 0; 
      text-decoration:none; 
      color:#333; 
      font-weight:bold; 
      font-size:1.1em; 
    }
    .sidebar a img.icon { 
      vertical-align:middle; 
      margin-right:8px; 
      width:24px; 
    }
    .content { 
      flex:1; 
      padding:20px; 
      margin-left:240px; 
    }
    .timeline { 
      max-width:600px; 
      margin:auto; 
    }
    .animal-card { 
      background:#fff; 
      border:1px solid #ddd; 
      border-radius:12px; 
      margin-bottom:20px; 
      box-shadow:0 0 10px rgba(0,0,0,0.05); 
    }
    .card-header { 
      display:flex; 
      align-items:center; 
      padding:10px; 
    }
    .card-header img { 
      width:40px; 
      height:40px; 
      border-radius:50%; 
      margin-right:10px; 
      object-fit:cover; 
    }
    .animal-img { 
      width:100%; 
      max-height:600px; 
      object-fit:cover; 
    }
    .card-body { 
      padding:10px; 
    }
    .card-footer { 
      padding:10px; 
      border-top:1px solid #eee;
      display:flex; 
      gap:15px; 
    }
    .card-footer button { 
      background:none; 
      border:none; 
      cursor:pointer; 
      font-size:1.2em; 
    }
    .adotar-btn { 
      display:inline-block; 
      background:linear-gradient(90deg, #ff77d0, #4ba8ff); 
      color:#fff; 
      padding:8px 15px; 
      border-radius:20px; 
      text-decoration:none; 
      font-weight:bold; 
      margin-top:10px; 
    }
    .notif-count { 
      background:#dc3545; 
      color:#fff; 
      border-radius:50%; 
      padding:2px 6px; 
      font-size:0.8em; 
      margin-left:5px; 
    }

    /* Estilos para os filtros */
    .filtros {
        max-width: 600px;
        margin: 0 auto 20px auto;
        background: #fff;
        padding: 10px;
        border-radius: 12px;
        box-shadow: 0 0 10px rgba(0,0,0,0.05);
        display: flex;
        justify-content: space-around;
        gap: 10px;
    }
    .filtro-btn {
        text-decoration: none;
        color: #555;
        font-weight: bold;
        padding: 8px 16px;
        border-radius: 20px;
        border: 1px solid transparent;
        transition: all 0.3s ease;
    }
    .filtro-btn:hover {
        background-color: #f0f0f0;
    }
    .filtro-btn.active {
        background: linear-gradient(90deg, #ff77d0, #4ba8ff);
        color: #fff;
        border-color: transparent;
    }
  </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
      <img src="../img/logo.png" alt="logo" style="width:50px; display:block; margin:0 auto 15px auto;">
    <h3>
      <img src="../uploads/<?php echo htmlspecialchars($foto_perfil); ?>" alt="Foto perfil" class="profile">
      @<?php echo htmlspecialchars($username); ?>
    </h3>
    <a href="home.php">
      <img src="https://img.icons8.com/ios/24/000000/home.png" class="icon" alt="Início">
      Início
    </a>
    <a href="<?php echo $tipo==='doador' ? 'notificacoes.php' : 'notificacoes_adotante.php'; ?>">
      <img src="https://img.icons8.com/ios/24/000000/appointment-reminders.png" class="icon" alt="Notificações">
      Notificações
      <?php if($notif_count>0): ?>
        <span class="notif-count"><?php echo $notif_count; ?></span>
      <?php endif; ?>
    </a>
    <a href="mensagens.php">
      <img src="https://img.icons8.com/ios/24/000000/chat.png" class="icon" alt="Mensagens">
      Mensagens
    </a>
    <a href="perfil.php">
      <img src="https://img.icons8.com/ios/24/000000/user.png" class="icon" alt="Perfil">
      Perfil
    </a>
    <?php if ($tipo === "doador"): ?>
      <a href="postar_animal.php">
        <img src="https://img.icons8.com/ios/24/000000/plus-math.png" class="icon" alt="Postar Animal">
        Postar Animal
      </a>
    <?php endif; ?>
    <a href="../auth/logout.php">
      <img src="https://img.icons8.com/ios/24/000000/exit.png" class="icon" alt="Sair">
      Sair
    </a>
  </div>

  <div class="content">
    <div class="timeline">
    
      <div class="filtros">
        <a href="home.php" class="filtro-btn <?php echo ($filtro_tipo === 'todos' ? 'active' : ''); ?>">Todos</a>
        <a href="home.php?filtro=cachorro" class="filtro-btn <?php echo ($filtro_tipo === 'cachorro' ? 'active' : ''); ?>">🐶 Cachorros</a>
        <a href="home.php?filtro=gato" class="filtro-btn <?php echo ($filtro_tipo === 'gato' ? 'active' : ''); ?>">🐱 Gatos</a>
      </div>

      <?php if (empty($animais)): ?>
        <p style="text-align:center;">Nenhum animal encontrado com este filtro.</p>
      <?php endif; ?>

      <?php foreach ($animais as $animal): ?>
        <div class="animal-card">
          <div class="card-header">
            <img src="../uploads/<?php echo htmlspecialchars($animal['foto_perfil'] ?? 'default.png'); ?>" alt="Foto Doador">
            <strong><?php echo htmlspecialchars($animal['username']); ?></strong>
          </div>
          <img src="../uploads/<?php echo htmlspecialchars($animal['foto']); ?>" alt="Foto Animal" class="animal-img">
          <div class="card-body">
            <h3><?php echo htmlspecialchars($animal['nome']); ?></h3>
            <p><strong>Idade:</strong> <?php echo htmlspecialchars($animal['idade']); ?> | <strong>Raça:</strong> <?php echo htmlspecialchars($animal['raca']); ?> | <strong>Local:</strong> <?php echo htmlspecialchars($animal['localizacao']); ?></p>
            <p><?php echo nl2br(htmlspecialchars($animal['observacoes'])); ?></p>
            <?php if ($tipo === 'adotante'): ?>
              <a href="solicitar_adocao.php?id_animal=<?php echo $animal['id']; ?>" class="adotar-btn">Quero Adotar</a>
            <?php endif; ?>
          </div>
          </div>
      <?php endforeach; ?>
    </div>
  </div>
</body>
</html>