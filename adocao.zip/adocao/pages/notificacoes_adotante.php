<?php
session_start();
require_once("../config/connection.php");

if (!isset($_SESSION['user_id']) || $_SESSION['tipo'] !== 'adotante') {
    header("Location: ../index.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$tipo = $_SESSION['tipo'];
$foto_perfil = $_SESSION['foto_perfil'] ?? 'default.png';

// Contagem de notificações do adotante
$stmt_notif = $conn->prepare("SELECT COUNT(*) FROM formularios_adocao WHERE id_adotante=:id AND status!='aguardando'");
$stmt_notif->execute([':id'=>$user_id]);
$notif_count = $stmt_notif->fetchColumn();

// Pega todas as solicitações do adotante que já foram respondidas
$stmt = $conn->prepare("
    SELECT f.*, a.nome AS animal_nome, u.username AS doador_nome, u.foto_perfil AS doador_foto
    FROM formularios_adocao f
    JOIN animais a ON f.id_animal = a.id
    JOIN usuarios u ON a.id_usuario = u.id
    WHERE f.id_adotante = :user_id AND f.status != 'aguardando'
    ORDER BY f.data_envio DESC
");
$stmt->execute([':user_id' => $user_id]);
$notificacoes = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Notificações</title>
<link rel="icon" type="image/png" href="../img/logo.png">
<style>
body { margin:0; font-family:Arial,sans-serif; background:#f4f4f4; display:flex; }
.sidebar { width:200px; background:#fff; padding:20px; height:100vh; position:fixed; box-shadow:2px 0 5px rgba(0,0,0,0.1); }
.sidebar h3 { margin-bottom:20px; display:flex; align-items:center; font-size:1em; }
.sidebar img.profile { width:40px; height:40px; border-radius:50%; margin-right:10px; object-fit:cover; }
.sidebar a { display:block; margin:15px 0; text-decoration:none; color:#333; font-weight:bold; font-size:1.1em; }
.sidebar a img.icon { vertical-align:middle; margin-right:8px; width:24px; }
.content { flex:1; padding:20px; margin-left:240px; }
.notificacao-card { border:1px solid #ddd; border-radius:12px; padding:10px; margin-bottom:15px; box-shadow:0 0 5px rgba(0,0,0,0.1); display:flex; align-items:center; background:#fff; }
.notificacao-card img { width:50px; height:50px; border-radius:50%; object-fit:cover; margin-right:10px; }
.status { font-weight:bold; margin-left:auto; padding:4px 8px; border-radius:6px; color:#fff; }
.status.aprovado { background:#28a745; }
.status.recusado { background:#dc3545; }
.notif-count { background:#dc3545; color:#fff; border-radius:50%; padding:2px 6px; font-size:0.8em; margin-left:5px; }
</style>
</head>
<body>
<!-- Sidebar -->
<div class="sidebar">
<img src="../img/logo.png" alt="logo" style="width:50px; display:block; margin:0 auto 15px auto;">
    <h3>
      <img src="../uploads/<?php echo htmlspecialchars($foto_perfil); ?>" alt="Foto perfil" class="profile">
      @<?php echo htmlspecialchars($username); ?>
    </h3>
    <a href="home.php">
      <img src="https://img.icons8.com/ios/24/000000/home.png" class="icon" alt="Início">
      Início
    </a>
    <a href="notificacoes_adotante.php">
      <img src="https://img.icons8.com/ios/24/000000/appointment-reminders.png" class="icon" alt="Notificações">
      Notificações
      <?php if($notif_count>0): ?>
        <span class="notif-count"><?php echo $notif_count; ?></span>
      <?php endif; ?>
    </a>
    <a href="mensagens.php">
      <img src="https://img.icons8.com/ios/24/000000/chat.png" class="icon" alt="Mensagens">
      Mensagens
    </a>
    <a href="perfil.php">
      <img src="https://img.icons8.com/ios/24/000000/user.png" class="icon" alt="Perfil">
      Perfil
    </a>
    <a href="../auth/logout.php">
      <img src="https://img.icons8.com/ios/24/000000/exit.png" class="icon" alt="Sair">
      Sair
    </a>
</div>

<div class="content">
<h2>Notificações</h2>

<?php if(!$notificacoes): ?>
    <p>Nenhuma notificação por enquanto.</p>
<?php else: ?>
    <?php foreach($notificacoes as $n): ?>
        <div class="notificacao-card">
            <img src="../uploads/<?php echo htmlspecialchars($n['doador_foto'] ?? 'default.png'); ?>" alt="Doador">
            <div>
                <strong><?php echo htmlspecialchars($n['doador_nome']); ?></strong> respondeu à sua solicitação de <strong><?php echo htmlspecialchars($n['animal_nome']); ?></strong>
            </div>
            <span class="status <?php echo $n['status']; ?>">
                <?php echo ucfirst($n['status']); ?>
            </span>
            <a href="ver_formulario.php?id=<?php echo $n['id']; ?>" target="_blank" style="margin-left:10px;">Ver formulário</a>
        </div>
    <?php endforeach; ?>
<?php endif; ?>
</div>
</body>
</html>