<?php
session_start();
require_once("../config/connection.php");

if (!isset($_SESSION['user_id']) || $_SESSION['tipo'] !== 'doador') {
    header("Location: ../index.php");
    exit;
}

$user_id = $_SESSION['user_id'];

// Pega todas as solicitações de adoção para os animais do doador
$stmt = $conn->prepare("
    SELECT f.*, a.nome AS animal_nome, u.username AS adotante_nome, u.foto_perfil AS adotante_foto
    FROM formularios_adocao f
    JOIN animais a ON f.id_animal = a.id
    JOIN usuarios u ON f.id_adotante = u.id
    WHERE a.id_usuario = :user_id
    ORDER BY f.data_envio DESC
");
$stmt->execute([':user_id' => $user_id]);
$solicitacoes = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Notificações</title>
<link rel="icon" type="image/png" href="../img/logo.png">
<style>
body { font-family: Arial, sans-serif; background:#fff; margin:0; display:flex; }
.sidebar {
    width:200px; 
    background:#fff; /* fundo branco */
    padding:20px; 
    height:100vh; 
    box-shadow:2px 0 5px rgba(0,0,0,0.1);
}
.sidebar h3 { margin-bottom:20px; display:flex; align-items:center; }
.sidebar img.profile { width:40px; height:40px; border-radius:50%; margin-right:10px; object-fit:cover; }
.sidebar a { display:block; margin:12px 0; text-decoration:none; color:#333; font-weight:bold; }
.sidebar a img.icon { vertical-align:middle; margin-right:5px; }
.content { flex:1; padding:20px; }
.solicitacao-card {
    border:1px solid #ddd; border-radius:12px; padding:10px; margin-bottom:15px; 
    box-shadow:0 0 5px rgba(0,0,0,0.1);
}
.solicitacao-card img { width:50px; height:50px; border-radius:50%; object-fit:cover; margin-right:10px; vertical-align:middle; }
button { padding:6px 12px; border:none; border-radius:6px; cursor:pointer; margin-right:5px; }
button.aprovar { background:#28a745; color:#fff; }
button.recusar { background:#dc3545; color:#fff; }
a.ver-form { text-decoration:none; color:#007bff; font-weight:bold; margin-left:5px; }
</style>
</head>
<body>
<div class="sidebar">
<img src="../img/logo.png" alt="logo" style="width:50px; display:block; margin:0 auto 15px auto;">
    <h3>
      <img src="../uploads/<?php echo htmlspecialchars($_SESSION['foto_perfil'] ?? 'default.png'); ?>" alt="Foto perfil" class="profile">
      @<?php echo htmlspecialchars($_SESSION['username']); ?>
    </h3>
    <a href="home.php">
      <img src="https://img.icons8.com/ios/24/000000/home.png" class="icon" alt="Início"> Início
    </a>
    <a href="notificacoes.php">
      <img src="https://img.icons8.com/ios/24/000000/appointment-reminders.png" class="icon" alt="Notificações"> Notificações
    </a>
    <a href="mensagens.php">
      <img src="https://img.icons8.com/ios/24/000000/chat.png" class="icon" alt="Mensagens"> Mensagens
    </a>
    <a href="perfil.php">
      <img src="https://img.icons8.com/ios/24/000000/user.png" class="icon" alt="Perfil"> Perfil
    </a>
    <a href="postar_animal.php">
      <img src="https://img.icons8.com/ios/24/000000/plus-math.png" class="icon" alt="Postar Animal"> Postar Animal
    </a>
    <a href="../auth/logout.php">
      <img src="https://img.icons8.com/ios/24/000000/exit.png" class="icon" alt="Sair"> Sair
    </a>
</div>

<div class="content">
<h2>Solicitações de Adoção</h2>

<?php if(!$solicitacoes): ?>
    <p>Nenhuma solicitação por enquanto.</p>
<?php else: ?>
    <?php foreach($solicitacoes as $sol): ?>
        <div class="solicitacao-card">
            <img src="../uploads/<?php echo htmlspecialchars($sol['adotante_foto'] ?? 'default.png'); ?>" alt="Foto adotante">
            <strong><?php echo htmlspecialchars($sol['adotante_nome']); ?></strong> solicitou adotar 
            <strong><?php echo htmlspecialchars($sol['animal_nome']); ?></strong><br>
            Status: <strong><?php echo ucfirst($sol['status']); ?></strong>
            <div style="margin-top:5px;">
                <a class="ver-form" href="ver_formulario.php?id=<?php echo $sol['id']; ?>" target="_blank">Ver Formulário</a>
                <?php if($sol['status'] === 'aguardando'): ?>
                    <form action="responder_solicitacao.php" method="post" style="display:inline;">
                        <input type="hidden" name="id_solicitacao" value="<?php echo $sol['id']; ?>">
                        <button type="submit" name="acao" value="aprovar" class="aprovar">Aprovar</button>
                        <button type="submit" name="acao" value="recusar" class="recusar">Recusar</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>
</div>
</body>
</html>
