<?php
session_start();
require_once("../config/connection.php");

if (!isset($_SESSION['user_id'])) {
    header("Location: ../index.php");
    exit;
}

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$tipo = $_SESSION['tipo'];
$foto_perfil = $_SESSION['foto_perfil'] ?? 'default.png';

// Contagem de notificações
if($tipo === 'doador'){
    $stmt_notif = $conn->prepare("SELECT COUNT(*) 
        FROM formularios_adocao f 
        JOIN animais a ON f.id_animal = a.id 
        WHERE a.id_usuario=:id AND f.status='aguardando'");
    $stmt_notif->execute([':id'=>$user_id]);
    $notif_count = $stmt_notif->fetchColumn();
} else {
    $stmt_notif = $conn->prepare("SELECT COUNT(*) 
        FROM formularios_adocao 
        WHERE id_adotante=:id AND status!='aguardando'");
    $stmt_notif->execute([':id'=>$user_id]);
    $notif_count = $stmt_notif->fetchColumn();
}

// Pega bio do usuário
$stmt = $conn->prepare("SELECT bio FROM usuarios WHERE id = :id");
$stmt->execute([':id' => $user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
$bio = $user['bio'] ?? '';

// Pega animais do usuário
if ($tipo === 'doador') {
    $sql_animais = "SELECT * FROM animais WHERE id_usuario = :id ORDER BY data_postagem DESC";
    $stmt_animais = $conn->prepare($sql_animais);
    $stmt_animais->execute([':id' => $user_id]);
    $animais = $stmt_animais->fetchAll(PDO::FETCH_ASSOC);
} else {
    $sql_animais = "SELECT a.*, f.status AS status_form
                    FROM formularios_adocao f
                    JOIN animais a ON f.id_animal = a.id
                    WHERE f.id_adotante = :id
                    ORDER BY f.data_envio DESC";
    $stmt_animais = $conn->prepare($sql_animais);
    $stmt_animais->execute([':id' => $user_id]);
    $animais = $stmt_animais->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Perfil - <?php echo htmlspecialchars($username); ?></title>
<link rel="icon" type="image/png" href="../img/logo.png">
<style>
body { margin:0; font-family:Arial,sans-serif; background:#f4f4f4; display:flex; }
.sidebar { width:200px; background:#fff; padding:20px; height:100vh; position:fixed; box-shadow:2px 0 5px rgba(0,0,0,0.1); }
.sidebar h3 { margin-bottom:20px; display:flex; align-items:center; font-size:1em; }
.sidebar img.profile { width:40px; height:40px; border-radius:50%; margin-right:10px; object-fit:cover; }
.sidebar a { display:block; margin:15px 0; text-decoration:none; color:#333; font-weight:bold; font-size:1.1em; }
.sidebar a img.icon { vertical-align:middle; margin-right:8px; width:24px; }
.content { flex:1; padding:20px; margin-left:240px; }
.profile-header { text-align:center; margin-bottom:30px; }
.profile-header img { width:120px; height:120px; border-radius:50%; object-fit:cover; margin-bottom:10px; }
.profile-header h3 { margin:5px 0; }
.profile-header p { font-size:1em; color:#555; }
.edit-btn { padding:8px 16px; border:none; background:#007bff; color:#fff; border-radius:8px; cursor:pointer; margin-top:10px; }
.animais-container { display:flex; flex-wrap:wrap; gap:20px; justify-content:center; }
.animal-card { border:1px solid #ddd; border-radius:12px; padding:10px; width:200px; box-shadow:0 0 5px rgba(0,0,0,0.1); text-align:center; background:#fff; }
.animal-card img { width:100%; height:120px; border-radius:10px; object-fit:cover; margin-bottom:5px; }
.animal-card p { font-size:0.9em; color:#555; margin:3px 0; }
.status { font-weight:bold; }
.user-type { color:#fff; font-size:0.8em; font-weight:bold; padding:2px 6px; border-radius:6px; margin-left:8px; }
.user-type.doador { background-color:#007bff; }
.user-type.adotante { background-color:#ff69b4; }
.notif-count { background:#dc3545; color:#fff; border-radius:50%; padding:2px 6px; font-size:0.8em; margin-left:5px; }
</style>
</head>
<body>
<!-- Sidebar -->
<div class="sidebar">
<img src="../img/logo.png" alt="logo" style="width:50px; display:block; margin:0 auto 15px auto;">
    <h3>
      <img src="../uploads/<?php echo htmlspecialchars($foto_perfil); ?>" alt="Foto perfil" class="profile">
      @<?php echo htmlspecialchars($username); ?>
      <span class="user-type <?php echo $tipo; ?>">
        <?php echo ucfirst($tipo); ?>
      </span>
    </h3>
    <a href="home.php">
      <img src="https://img.icons8.com/ios/24/000000/home.png" class="icon" alt="Início">
      Início
    </a>
    <a href="<?php echo $tipo==='doador' ? 'notificacoes.php' : 'notificacoes_adotante.php'; ?>">
      <img src="https://img.icons8.com/ios/24/000000/appointment-reminders.png" class="icon" alt="Notificações">
      Notificações
      <?php if($notif_count>0): ?>
        <span class="notif-count"><?php echo $notif_count; ?></span>
      <?php endif; ?>
    </a>
    <a href="mensagens.php">
      <img src="https://img.icons8.com/ios/24/000000/chat.png" class="icon" alt="Mensagens">
      Mensagens
    </a>
    <a href="perfil.php">
      <img src="https://img.icons8.com/ios/24/000000/user.png" class="icon" alt="Perfil">
      Perfil
    </a>
    <?php if ($tipo === "doador"): ?>
      <a href="postar_animal.php">
        <img src="https://img.icons8.com/ios/24/000000/plus-math.png" class="icon" alt="Postar Animal">
        Postar Animal
      </a>
    <?php endif; ?>
    <a href="../auth/logout.php">
      <img src="https://img.icons8.com/ios/24/000000/exit.png" class="icon" alt="Sair">
      Sair
    </a>
</div>

<!-- Conteúdo principal -->
<div class="content">
  <div class="profile-header">
    <img src="../uploads/<?php echo htmlspecialchars($foto_perfil); ?>" alt="Foto perfil">
    <h3>
      @<?php echo htmlspecialchars($username); ?>
      <span class="user-type <?php echo $tipo; ?>">
        <?php echo ucfirst($tipo); ?>
      </span>
    </h3>
    <p><?php echo nl2br(htmlspecialchars($bio)); ?></p>
    <button class="edit-btn" onclick="window.location.href='editar_perfil.php'">Editar Perfil</button>
  </div>

  <h2><?php echo $tipo === 'doador' ? 'Meus Animais' : 'Meus Animais Adotados / Em Análise'; ?></h2>
  <div class="animais-container">
    <?php foreach($animais as $animal): ?>
      <div class="animal-card">
        <?php if(!empty($animal['foto'])): ?>
          <img src="../uploads/<?php echo htmlspecialchars($animal['foto']); ?>" alt="Foto animal">
        <?php else: ?>
          <img src="../uploads/default.png" alt="Foto animal">
        <?php endif; ?>
        <p><b><?php echo htmlspecialchars($animal['nome']); ?></b></p>
        <p><?php echo htmlspecialchars($animal['tipo']); ?> - <?php echo htmlspecialchars($animal['raca']); ?></p>
        <p class="status">
          <?php 
            if($tipo === 'doador') echo ucfirst($animal['status']);
            else echo ucfirst($animal['status_form']); 
          ?>
        </p>
      </div>
    <?php endforeach; ?>
  </div>
</div>
</body>
</html>
